// Firebase configuration
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { getFirestore, doc, setDoc, getDoc, updateDoc, collection, addDoc, getDocs, deleteDoc, query, where } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyBxql7prksQBFHGhcl0ROn0ZhU_xjgWxho",
  authDomain: "anyioyoa.firebaseapp.com",
  projectId: "anyioyoa",
  storageBucket: "anyioyoa.firebasestorage.app",
  messagingSenderId: "67841636591",
  appId: "1:67841636591:web:f2aef2452bec50f670431a",
  measurementId: "G-251QFKDDQL"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export { auth, db, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, onAuthStateChanged, doc, setDoc, getDoc, updateDoc, collection, addDoc, getDocs, deleteDoc, query, where };