import { 
    auth, db, signInWithEmailAndPassword, createUserWithEmailAndPassword, 
    signOut, onAuthStateChanged, doc, setDoc, getDoc, updateDoc, 
    collection, addDoc, getDocs, deleteDoc, query, where 
} from './firebase-config.js';

// Global variables
let currentUser = null;
let currentPage = 'home';
let userData = null;

// Check if user is admin
const isAdmin = (email) => {
    return email === 'mjoga689@gmail.com';
};

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    loadPage('home');
    setupNavigation();
    checkAuthState();
    setupSupportButton();
});

// Navigation setup
function setupNavigation() {
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', (e) => {
            const page = e.currentTarget.dataset.page;
            document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
            e.currentTarget.classList.add('active');
            loadPage(page);
        });
    });
}

// Load page content
async function loadPage(page) {
    currentPage = page;
    const content = document.getElementById('mainContent');
    
    switch(page) {
        case 'home':
            content.innerHTML = await getHomePage();
            break;
        case 'task':
            content.innerHTML = await getTaskPage();
            break;
        case 'tournament':
            content.innerHTML = await getTournamentPage();
            break;
        case 'about':
            content.innerHTML = await getAboutPage();
            break;
        case 'support':
            content.innerHTML = await getSupportPage();
            break;
        case 'account':
            content.innerHTML = await getAccountPage();
            break;
    }
}

// Home Page
async function getHomePage() {
    const isVerified = userData?.verified || false;
    
    return `
        <div class="container">
            <h1 class="site-name-center">tunff09</h1>
            
            <div class="card text-center">
                <h1 class="mb-4">প্রতি সপ্তাহ বিশ হাজার টাকার টুর্নামেন্ট</h1>
                <p class="lead">টুর্নামেন্ট ততক্ষণ চলবে যতক্ষণ না ইউজার এর কয়েন সেস না হয়</p>
                
                ${!currentUser ? `
                    <div class="row g-3">
                        <div class="col-md-6">
                            <button class="btn w-100" onclick="showAuthModal('login')">Login</button>
                        </div>
                        <div class="col-md-6">
                            <button class="btn btn-secondary w-100" onclick="showAuthModal('signup')">Sign Up</button>
                        </div>
                    </div>
                ` : ''}
                
                ${currentUser && !isVerified ? `
                    <div class="alert alert-warning mt-3">
                        <h4>একাউন্ট ভেরিফাই করুন</h4>
                        <p>টুর্নামেন্টে জয়েন করতে হলে একাউন্ট ভেরিফাই করুন</p>
                        <button class="btn" onclick="loadPage('account')">ভেরিফাই এখনই</button>
                    </div>
                ` : ''}
            </div>
            
            <!-- Ads Container -->
            <div class="ads-container" id="monetage-ads"></div>
            
            <!-- Tournament Preview -->
            <div class="card">
                <h3>চলমান টুর্নামেন্ট</h3>
                <div id="tournamentPreview"></div>
            </div>
        </div>
    `;
}

// Task Page
async function getTaskPage() {
    const tasks = await loadTasks();
    
    return `
        <div class="container">
            <h2 class="text-center mb-4">Daily Tasks</h2>
            
            <div class="coin-display text-center mb-4">
                <i class="bi bi-coin"></i> Your Coins: ${userData?.coins || 0}
            </div>
            
            <div id="tasksList">
                ${tasks.map(task => `
                    <div class="card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h4>${task.title}</h4>
                                <p>Reward: ${task.reward} Coins</p>
                            </div>
                            <button class="btn btn-sm" onclick="completeTask('${task.id}')">
                                Complete
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
            
            <!-- YouTube Task Section -->
            <div class="card mt-4">
                <h4>YouTube Task</h4>
                <p>Watch full video and enter the code</p>
                <input type="text" class="form-control mb-3" placeholder="Enter verification code" id="youtubeCode">
                <button class="btn" onclick="verifyYouTubeTask()">Claim Coins</button>
            </div>
        </div>
    `;
}

// Tournament Page
async function getTournamentPage() {
    const tournaments = await loadTournaments();
    
    return `
        <div class="container">
            <h2 class="text-center mb-4">Tournaments</h2>
            
            <div id="tournamentsList">
                ${tournaments.map(tournament => `
                    <div class="tournament-card card">
                        <h3>${tournament.name}</h3>
                        <div class="prize">🏆 Prize: ৳${tournament.prize}</div>
                        <div class="entry-fee">Entry: ${tournament.entryFee} Coins</div>
                        <div>Players: ${tournament.currentPlayers}/${tournament.maxPlayers}</div>
                        <div>Type: ${tournament.type}</div>
                        <div>Map: ${tournament.map}</div>
                        <button class="btn mt-3" onclick="joinTournament('${tournament.id}')">
                            Join Tournament
                        </button>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

// About Page
async function getAboutPage() {
    const aboutContent = await getAboutContent();
    
    return `
        <div class="container">
            <h2 class="text-center mb-4">About Tournament</h2>
            
            <div class="card">
                <h3>Tournament Rules</h3>
                <ul class="list-unstyled">
                    <li class="mb-3">✓ কোন চিটিংবাজি করা যাবে না</li>
                    <li class="mb-3">✓ ফোন হ্যাক ইউজ করা যাবে না</li>
                    <li class="mb-3">✓ পপআপ ইউজার অ্যাপ এ ওপেন করার সাথে সাথে আইডি হতে হবে ৪০ লেভেলের উপরে</li>
                    <li class="mb-3">✓ একই আইপি থেকে একাধিক অ্যাকাউন্ট খুললে অটোমেটিক ব্লক করে দিবে</li>
                    <li class="mb-3">✓ ফ্রী ফায়ার ইউ আইডি দিয়ে ডিটেক্ট করা হবে</li>
                    <li class="mb-3">✓ প্রোফাইল ঠিক মত ভেরিফাই করতে হবে</li>
                </ul>
            </div>
            
            <div class="card mt-4" id="aboutDynamicContent">
                ${aboutContent || 'Loading...'}
            </div>
        </div>
    `;
}

// Support Page
function getSupportPage() {
    return `
        <div class="container">
            <h2 class="text-center mb-4">Support Center</h2>
            
            <div class="card text-center">
                <h3>Contact Support</h3>
                <div class="row g-4 mt-3">
                    <div class="col-md-6">
                        <div class="p-4 bg-success bg-opacity-25 rounded">
                            <i class="bi bi-whatsapp display-4"></i>
                            <h4>WhatsApp</h4>
                            <p>+8801234567890</p>
                            <a href="https://wa.me/8801234567890" class="btn" target="_blank">
                                Chat Now
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="p-4 bg-info bg-opacity-25 rounded">
                            <i class="bi bi-telegram display-4"></i>
                            <h4>Telegram</h4>
                            <p>@ffsupport</p>
                            <a href="https://t.me/ffsupport" class="btn" target="_blank">
                                Join Group
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Account Page
async function getAccountPage() {
    if (!currentUser) {
        return `
            <div class="container">
                <div class="card text-center">
                    <h3>Please Login First</h3>
                    <button class="btn" onclick="showAuthModal('login')">Login</button>
                </div>
            </div>
        `;
    }
    
    return `
        <div class="container">
            <h2 class="text-center mb-4">My Account</h2>
            
            <div class="card">
                <h3>Profile Information</h3>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Free Fire ID</label>
                            <input type="text" class="form-control" id="ffId" value="${userData?.ffId || ''}">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Phone Number (WhatsApp)</label>
                            <input type="text" class="form-control" id="phoneNumber" value="${userData?.phone || ''}">
                        </div>
                    </div>
                </div>
                <button class="btn mt-3" onclick="verifyAccount()">Verify Account</button>
            </div>
            
            <div class="card mt-4">
                <h3>Task History</h3>
                <div id="taskHistory">
                    ${await getTaskHistory()}
                </div>
            </div>
            
            <div class="card mt-4">
                <h3>Coins Balance</h3>
                <div class="coin-display">${userData?.coins || 0} Coins</div>
            </div>
        </div>
    `;
}

// Auth Modal
function showAuthModal(type) {
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.id = 'authModal';
    modal.innerHTML = `
        <div class="modal-dialog">
            <div class="modal-content bg-dark text-white">
                <div class="modal-header">
                    <h5 class="modal-title">${type === 'login' ? 'Login' : 'Sign Up'}</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="authForm">
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" class="form-control" id="email" required>
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" class="form-control" id="password" required>
                        </div>
                        ${type === 'signup' ? `
                            <div class="form-group">
                                <label>Free Fire ID</label>
                                <input type="text" class="form-control" id="ffId">
                            </div>
                        ` : ''}
                    </form>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button class="btn" onclick="handleAuth('${type}')">Submit</button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    new bootstrap.Modal(modal).show();
    
    modal.addEventListener('hidden.bs.modal', () => {
        modal.remove();
    });
}

// Handle Authentication
async function handleAuth(type) {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    try {
        if (type === 'login') {
            const userCredential = await signInWithEmailAndPassword(auth, email, password);
            showToast('Login successful!');
        } else {
            const userCredential = await createUserWithEmailAndPassword(auth, email, password);
            const ffId = document.getElementById('ffId').value;
            
            // Save user data to Firestore
            await setDoc(doc(db, 'users', userCredential.user.uid), {
                email: email,
                ffId: ffId,
                coins: 100, // Welcome bonus
                verified: false,
                createdAt: new Date().toISOString(),
                tasks: []
            });
            
            showToast('Sign up successful! Welcome bonus 100 coins added.');
        }
        
        bootstrap.Modal.getInstance(document.getElementById('authModal')).hide();
    } catch (error) {
        showToast(error.message, 'error');
    }
}

// Check Auth State
function checkAuthState() {
    onAuthStateChanged(auth, async (user) => {
        if (user) {
            currentUser = user;
            
            // Check if admin
            if (isAdmin(user.email)) {
                document.getElementById('adminButton').style.display = 'block';
            }
            
            // Load user data
            const userDoc = await getDoc(doc(db, 'users', user.uid));
            if (userDoc.exists()) {
                userData = userDoc.data();
            }
            
            // Refresh current page
            if (currentPage) {
                loadPage(currentPage);
            }
        } else {
            currentUser = null;
            userData = null;
            document.getElementById('adminButton').style.display = 'none';
            
            if (currentPage) {
                loadPage(currentPage);
            }
        }
    });
}

// Verify Account
async function verifyAccount() {
    if (!currentUser) return;
    
    const ffId = document.getElementById('ffId')?.value;
    const phone = document.getElementById('phoneNumber')?.value;
    
    await updateDoc(doc(db, 'users', currentUser.uid), {
        ffId: ffId,
        phone: phone,
        verified: true
    });
    
    userData.verified = true;
    showToast('Account verified successfully!');
    loadPage('account');
}

// Join Tournament
async function joinTournament(tournamentId) {
    if (!currentUser) {
        showToast('Please login first', 'error');
        return;
    }
    
    if (!userData?.verified) {
        showToast('Please verify your account first', 'error');
        return;
    }
    
    // Check if user has enough coins
    const tournament = await getDoc(doc(db, 'tournaments', tournamentId));
    if (tournament.exists()) {
        const tourData = tournament.data();
        
        if (userData.coins < tourData.entryFee) {
            showToast('Not enough coins! Complete tasks to earn more.', 'error');
            return;
        }
        
        // Deduct coins
        await updateDoc(doc(db, 'users', currentUser.uid), {
            coins: userData.coins - tourData.entryFee
        });
        
        // Add user to tournament
        await updateDoc(doc(db, 'tournaments', tournamentId), {
            currentPlayers: tourData.currentPlayers + 1
        });
        
        showToast('Successfully joined tournament!');
        loadPage('tournament');
    }
}

// Complete Task
async function completeTask(taskId) {
    if (!currentUser) {
        showToast('Please login first', 'error');
        return;
    }
    
    const task = await getDoc(doc(db, 'tasks', taskId));
    if (task.exists()) {
        const taskData = task.data();
        
        // Add coins
        await updateDoc(doc(db, 'users', currentUser.uid), {
            coins: userData.coins + taskData.reward
        });
        
        userData.coins += taskData.reward;
        showToast(`+${taskData.reward} coins earned!`);
        loadPage('task');
    }
}

// Load Tasks from Firestore
async function loadTasks() {
    const tasksSnapshot = await getDocs(collection(db, 'tasks'));
    return tasksSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
    }));
}

// Load Tournaments from Firestore
async function loadTournaments() {
    const tournamentsSnapshot = await getDocs(collection(db, 'tournaments'));
    return tournamentsSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
    }));
}

// Get About Content
async function getAboutContent() {
    const aboutDoc = await getDoc(doc(db, 'settings', 'about'));
    return aboutDoc.exists() ? aboutDoc.data().content : '';
}

// Get Task History
async function getTaskHistory() {
    if (!userData?.tasks || userData.tasks.length === 0) {
        return '<p>No tasks completed yet</p>';
    }
    
    return userData.tasks.map(task => `
        <div class="d-flex justify-content-between">
            <span>${task.name}</span>
            <span>+${task.reward} coins</span>
            <span class="text-muted">${new Date(task.completedAt).toLocaleDateString()}</span>
        </div>
    `).join('');
}

// Support button toggle
function toggleSupport() {
    document.getElementById('supportOptions').classList.toggle('show');
}

// Setup support button click outside
function setupSupportButton() {
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.support-floating')) {
            document.getElementById('supportOptions')?.classList.remove('show');
        }
    });
}

// Show toast notification
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

// YouTube Task Verification
async function verifyYouTubeTask() {
    const code = document.getElementById('youtubeCode')?.value;
    
    if (code === 'FF2024') { // Example code
        await updateDoc(doc(db, 'users', currentUser.uid), {
            coins: userData.coins + 50
        });
        
        userData.coins += 50;
        showToast('+50 coins earned!');
    } else {
        showToast('Invalid code', 'error');
    }
}

// Make functions global for onclick events
window.showAuthModal = showAuthModal;
window.handleAuth = handleAuth;
window.toggleSupport = toggleSupport;
window.verifyAccount = verifyAccount;
window.joinTournament = joinTournament;
window.completeTask = completeTask;
window.verifyYouTubeTask = verifyYouTubeTask;
window.loadPage = loadPage;
