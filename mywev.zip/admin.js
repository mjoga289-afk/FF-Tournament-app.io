import { 
    auth, db, getDocs, collection, addDoc, deleteDoc, doc, updateDoc, getDoc, query, where 
} from './firebase-config.js';

// Check if user is admin
onAuthStateChanged(auth, (user) => {
    if (!user || user.email !== 'mjoga689@gmail.com') {
        window.location.href = 'index.html';
    } else {
        loadDashboard();
        loadAllUsers();
        loadTasks();
        loadTournaments();
        loadPopups();
    }
});

// Navigation
document.querySelectorAll('.admin-sidebar .nav-link').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        
        document.querySelectorAll('.admin-sidebar .nav-link').forEach(l => l.classList.remove('active'));
        link.classList.add('active');
        
        const section = link.dataset.section;
        document.querySelectorAll('.admin-section').forEach(s => s.style.display = 'none');
        document.getElementById(section).style.display = 'block';
        
        if (section === 'tournaments') {
            loadTournamentSelect();
        }
    });
});

// Load Dashboard
async function loadDashboard() {
    // Load stats
    const usersSnapshot = await getDocs(collection(db, 'users'));
    const totalUsers = usersSnapshot.size;
    document.getElementById('totalUsers').textContent = totalUsers;
    
    const verifiedUsers = usersSnapshot.docs.filter(doc => doc.data().verified).length;
    document.getElementById('verifiedUsers').textContent = verifiedUsers;
    
    const tasksSnapshot = await getDocs(collection(db, 'tasks'));
    document.getElementById('totalTasks').textContent = tasksSnapshot.size;
    
    const tournamentsSnapshot = await getDocs(collection(db, 'tournaments'));
    const activeTournaments = tournamentsSnapshot.docs.filter(doc => {
        const endDate = new Date(doc.data().endDate);
        return endDate > new Date();
    }).length;
    document.getElementById('activeTournaments').textContent = activeTournaments;
    
    // Load recent users
    const recentUsers = usersSnapshot.docs.slice(0, 5);
    const tbody = document.getElementById('recentUsersTable');
    tbody.innerHTML = recentUsers.map(doc => {
        const data = doc.data();
        return `
            <tr>
                <td>${data.email}</td>
                <td>${data.ffId || '-'}</td>
                <td>${data.coins || 0}</td>
                <td>${data.verified ? '✅' : '❌'}</td>
                <td>
                    <button class="btn btn-sm btn-primary" onclick="editUser('${doc.id}')">
                        <i class="bi bi-pencil"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

// Load All Users
async function loadAllUsers() {
    const usersSnapshot = await getDocs(collection(db, 'users'));
    const tbody = document.getElementById('usersTable');
    tbody.innerHTML = usersSnapshot.docs.map(doc => {
        const data = doc.data();
        return `
            <tr>
                <td>${data.email}</td>
                <td>${data.ffId || '-'}</td>
                <td>${data.phone || '-'}</td>
                <td>${data.coins || 0}</td>
                <td>${data.verified ? '✅' : '❌'}</td>
                <td class="action-btns">
                    <button class="btn btn-sm btn-primary" onclick="editUser('${doc.id}')">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deleteUser('${doc.id}')">
                        <i class="bi bi-trash"></i>
                    </button>
                    <button class="btn btn-sm btn-success" onclick="addCoins('${doc.id}')">
                        <i class="bi bi-plus-circle"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
    
    // Search functionality
    document.getElementById('searchUser').addEventListener('input', (e) => {
        const search = e.target.value.toLowerCase();
        const rows = document.querySelectorAll('#usersTable tr');
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(search) ? '' : 'none';
        });
    });
}

// Load Tasks
async function loadTasks() {
    const tasksSnapshot = await getDocs(collection(db, 'tasks'));
    const tbody = document.getElementById('tasksTable');
    tbody.innerHTML = tasksSnapshot.docs.map(doc => {
        const data = doc.data();
        return `
            <tr>
                <td>${data.title}</td>
                <td>${data.type}</td>
                <td>${data.reward}</td>
                <td><span class="badge bg-success">Active</span></td>
                <td class="action-btns">
                    <button class="btn btn-sm btn-primary" onclick="editTask('${doc.id}')">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deleteTask('${doc.id}')">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

// Load Tournaments
async function loadTournaments() {
    const tournamentsSnapshot = await getDocs(collection(db, 'tournaments'));
    const tbody = document.getElementById('tournamentsTable');
    tbody.innerHTML = tournamentsSnapshot.docs.map(doc => {
        const data = doc.data();
        const status = new Date(data.endDate) > new Date() ? 'Active' : 'Ended';
        return `
            <tr>
                <td>${data.name}</td>
                <td>৳${data.prize}</td>
                <td>${data.entryFee} coins</td>
                <td>${data.currentPlayers || 0}/${data.maxPlayers}</td>
                <td><span class="badge bg-${status === 'Active' ? 'success' : 'secondary'}">${status}</span></td>
                <td class="action-btns">
                    <button class="btn btn-sm btn-primary" onclick="editTournament('${doc.id}')">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deleteTournament('${doc.id}')">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

// Load Tournament Select
async function loadTournamentSelect() {
    const tournamentsSnapshot = await getDocs(collection(db, 'tournaments'));
    const select = document.getElementById('tournamentSelect');
    select.innerHTML = '<option value="">Select Tournament</option>' + 
        tournamentsSnapshot.docs.map(doc => {
            return `<option value="${doc.id}">${doc.data().name}</option>`;
        }).join('');
}

// Load Popups
async function loadPopups() {
    const popupsSnapshot = await getDocs(collection(db, 'popups'));
    const tbody = document.getElementById('popupsTable');
    tbody.innerHTML = popupsSnapshot.docs.map(doc => {
        const data = doc.data();
        return `
            <tr>
                <td>${data.title}</td>
                <td><img src="${data.image}" style="height: 50px;" alt=""></td>
                <td><span class="badge bg-success">Active</span></td>
                <td class="action-btns">
                    <button class="btn btn-sm btn-danger" onclick="deletePopup('${doc.id}')">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

// Show Add Task Modal
function showAddTaskModal() {
    document.getElementById('taskForm').reset();
    document.getElementById('taskModal').querySelector('.modal-title').textContent = 'Add New Task';
    window.currentTaskId = null;
    new bootstrap.Modal(document.getElementById('taskModal')).show();
}

// Save Task
async function saveTask() {
    const taskData = {
        title: document.getElementById('taskTitle').value,
        type: document.getElementById('taskType').value,
        reward: parseInt(document.getElementById('taskReward').value),
        code: document.getElementById('taskCode').value,
        createdAt: new Date().toISOString()
    };
    
    if (window.currentTaskId) {
        await updateDoc(doc(db, 'tasks', window.currentTaskId), taskData);
    } else {
        await addDoc(collection(db, 'tasks'), taskData);
    }
    
    bootstrap.Modal.getInstance(document.getElementById('taskModal')).hide();
    loadTasks();
}

// Edit Task
async function editTask(taskId) {
    const taskDoc = await getDoc(doc(db, 'tasks', taskId));
    const task = taskDoc.data();
    
    document.getElementById('taskTitle').value = task.title;
    document.getElementById('taskType').value = task.type;
    document.getElementById('taskReward').value = task.reward;
    document.getElementById('taskCode').value = task.code || '';
    
    window.currentTaskId = taskId;
    document.getElementById('taskModal').querySelector('.modal-title').textContent = 'Edit Task';
    new bootstrap.Modal(document.getElementById('taskModal')).show();
}

// Delete Task
async function deleteTask(taskId) {
    if (confirm('Are you sure?')) {
        await deleteDoc(doc(db, 'tasks', taskId));
        loadTasks();
    }
}

// Show Add Tournament Modal
function showAddTournamentModal() {
    document.getElementById('tournamentForm').reset();
    document.getElementById('tournamentModal').querySelector('.modal-title').textContent = 'Add New Tournament';
    window.currentTournamentId = null;
    new bootstrap.Modal(document.getElementById('tournamentModal')).show();
}

// Save Tournament
async function saveTournament() {
    const tournamentData = {
        name: document.getElementById('tournamentName').value,
        prize: parseInt(document.getElementById('tournamentPrize').value),
        entryFee: parseInt(document.getElementById('tournamentEntryFee').value),
        maxPlayers: parseInt(document.getElementById('tournamentMaxPlayers').value),
        type: document.getElementById('tournamentType').value,
        map: document.getElementById('tournamentMap').value,
        startDate: document.getElementById('tournamentStartDate').value,
        endDate: document.getElementById('tournamentEndDate').value,
        currentPlayers: 0,
        createdAt: new Date().toISOString()
    };
    
    if (window.currentTournamentId) {
        await updateDoc(doc(db, 'tournaments', window.currentTournamentId), tournamentData);
    } else {
        await addDoc(collection(db, 'tournaments'), tournamentData);
    }
    
    bootstrap.Modal.getInstance(document.getElementById('tournamentModal')).hide();
    loadTournaments();
    loadTournamentSelect();
}

// Edit Tournament
async function editTournament(tournamentId) {
    const tourDoc = await getDoc(doc(db, 'tournaments', tournamentId));
    const tour = tourDoc.data();
    
    document.getElementById('tournamentName').value = tour.name;
    document.getElementById('tournamentPrize').value = tour.prize;
    document.getElementById('tournamentEntryFee').value = tour.entryFee;
    document.getElementById('tournamentMaxPlayers').value = tour.maxPlayers;
    document.getElementById('tournamentType').value = tour.type;
    document.getElementById('tournamentMap').value = tour.map;
    document.getElementById('tournamentStartDate').value = tour.startDate;
    document.getElementById('tournamentEndDate').value = tour.endDate;
    
    window.currentTournamentId = tournamentId;
    document.getElementById('tournamentModal').querySelector('.modal-title').textContent = 'Edit Tournament';
    new bootstrap.Modal(document.getElementById('tournamentModal')).show();
}

// Delete Tournament
async function deleteTournament(tournamentId) {
    if (confirm('Are you sure?')) {
        await deleteDoc(doc(db, 'tournaments', tournamentId));
        loadTournaments();
        loadTournamentSelect();
    }
}

// Upload Room Details
async function uploadRoomDetails() {
    const tournamentId = document.getElementById('tournamentSelect').value;
    const roomId = document.getElementById('roomId').value;
    const password = document.getElementById('roomPassword').value;
    const winnerCount = parseInt(document.getElementById('winnerCount').value);
    
    if (!tournamentId || !roomId || !password) {
        alert('Please fill all fields');
        return;
    }
    
    // Get tournament participants
    const tournamentDoc = await getDoc(doc(db, 'tournaments', tournamentId));
    const tournament = tournamentDoc.data();
    
    // Get all users who joined this tournament
    const usersSnapshot = await getDocs(collection(db, 'users'));
    const participants = usersSnapshot.docs.filter(doc => {
        const data = doc.data();
        return data.joinedTournaments && data.joinedTournaments.includes(tournamentId);
    });
    
    // Randomly select winners
    const shuffled = participants.sort(() => 0.5 - Math.random());
    const winners = shuffled.slice(0, Math.min(winnerCount, participants.length));
    
    // Send room details to winners
    for (const winner of winners) {
        const winnerData = winner.data();
        
        // Save notification
        await addDoc(collection(db, 'notifications'), {
            userId: winner.id,
            title: 'Tournament Room Details',
            message: `Room ID: ${roomId}\nPassword: ${password}`,
            type: 'success',
            createdAt: new Date().toISOString()
        });
        
        // Could also send via email/SMS here
    }
    
    // Send consolation messages to others
    const losers = participants.filter(p => !winners.includes(p));
    for (const loser of losers) {
        await addDoc(collection(db, 'notifications'), {
            userId: loser.id,
            title: 'Better Luck Next Time',
            message: 'হতাশ হবেন না! পরের টুর্নামেন্টে আবার জয়েন করুন। কয়েন কালেক্ট করতে থাকুন!',
            type: 'info',
            createdAt: new Date().toISOString()
        });
    }
    
    alert(`Room details sent to ${winners.length} winners and ${losers.length} consolation messages!`);
}

// Save About Content
async function saveAboutContent() {
    const content = document.getElementById('aboutContent').value;
    await setDoc(doc(db, 'settings', 'about'), { content });
    alert('About page updated!');
}

// Load About Content
async function loadAboutContent() {
    const aboutDoc = await getDoc(doc(db, 'settings', 'about'));
    if (aboutDoc.exists()) {
        document.getElementById('aboutContent').value = aboutDoc.data().content;
    }
}

// Show Add Popup Modal
function showAddPopupModal() {
    document.getElementById('popupForm').reset();
    new bootstrap.Modal(document.getElementById('popupModal')).show();
}

// Save Popup
async function savePopup() {
    const popupData = {
        title: document.getElementById('popupTitle').value,
        image: document.getElementById('popupImage').value,
        link: document.getElementById('popupLink').value,
        createdAt: new Date().toISOString()
    };
    
    await addDoc(collection(db, 'popups'), popupData);
    bootstrap.Modal.getInstance(document.getElementById('popupModal')).hide();
    loadPopups();
}

// Delete Popup
async function deletePopup(popupId) {
    if (confirm('Are you sure?')) {
        await deleteDoc(doc(db, 'popups', popupId));
        loadPopups();
    }
}

// Edit User
let currentEditingUser = null;

async function editUser(userId) {
    currentEditingUser = userId;
    const userDoc = await getDoc(doc(db, 'users', userId));
    const user = userDoc.data();
    
    document.getElementById('editFFId').value = user.ffId || '';
    document.getElementById('editPhone').value = user.phone || '';
    document.getElementById('editCoins').value = user.coins || 0;
    document.getElementById('editStatus').value = user.status || 'active';
    
    new bootstrap.Modal(document.getElementById('userEditModal')).show();
}

// Update User
async function updateUser() {
    const updates = {
        ffId: document.getElementById('editFFId').value,
        phone: document.getElementById('editPhone').value,
        coins: parseInt(document.getElementById('editCoins').value),
        status: document.getElementById('editStatus').value
    };
    
    await updateDoc(doc(db, 'users', currentEditingUser), updates);
    bootstrap.Modal.getInstance(document.getElementById('userEditModal')).hide();
    loadAllUsers();
    loadDashboard();
}

// Delete User
async function deleteUser(userId) {
    if (confirm('Are you sure you want to delete this user?')) {
        await deleteDoc(doc(db, 'users', userId));
        loadAllUsers();
        loadDashboard();
    }
}

// Add Coins
function addCoins(userId) {
    const amount = prompt('Enter coin amount to add:');
    if (amount && !isNaN(amount)) {
        // This will be implemented in the modal
        editUser(userId);
    }
}

// Make functions global
window.showAddTaskModal = showAddTaskModal;
window.saveTask = saveTask;
window.editTask = editTask;
window.deleteTask = deleteTask;
window.showAddTournamentModal = showAddTournamentModal;
window.saveTournament = saveTournament;
window.editTournament = editTournament;
window.deleteTournament = deleteTournament;
window.uploadRoomDetails = uploadRoomDetails;
window.saveAboutContent = saveAboutContent;
window.showAddPopupModal = showAddPopupModal;
window.savePopup = savePopup;
window.deletePopup = deletePopup;
window.editUser = editUser;
window.updateUser = updateUser;
window.deleteUser = deleteUser;
window.addCoins = addCoins;